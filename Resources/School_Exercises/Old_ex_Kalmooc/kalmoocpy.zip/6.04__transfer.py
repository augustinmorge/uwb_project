from roblib import *  # available at https://www.ensta-bretagne.fr/jaulin/roblib.py
M = array([[1,2],[3,4]])
print(M)